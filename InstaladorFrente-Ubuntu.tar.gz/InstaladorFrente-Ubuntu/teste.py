import socket
from time import sleep
df1 = '524554522034343438313831353736434f4e4649472e4578700d0a'
df2 = '5459504520490d0a'
#df3 = '317c6573745f7064765f686f72617a6175746f30317c6573745f6765725f75747a6d656e75767374656330317c6573745f696e695f736574696e74657266616365736d616b30317c6573745f6469735f76616c6d696e636564756c617330317c6573745f7064765f69647061796661636530317c6573745f62696f5f706573717569736130317c6573745f6765725f6d617866696e616c33377c6573745f6765725f636f6e667065736f657469717565746130317c6573745f6765725f65786264657363636f6e667065736f30317c6573745f6765725f746f6c646976636f6e667065736f657469717565746133377c6573745f696e695f7574696c63667476696e74656c6272617330317c6573745f696e695f697063667476696e74656c6272617330317c6573745f696e695f706f72746163667476696e74656c6272617333377c6573745f696e695f706f72746175647063667476696e74656c6272617333377c6573745f696e695f636d64697370656e73657230317c6573745f6469735f71746432303033377c6573745f6469735f7174643530303033377c6573745f6469735f717464313030303033377c6573745f6469735f717464323030303033377c6573745f6765725f636d64617469766172736330317c6573745f6765725f63737067617661626572746130317c6573745f6765725f7574696c697a6161636573736962696c696461646530317c6573745f6e66635f696d706469766973616f6375706f6d30317c6573745f696e695f7574696c656173696361736830317c6573745f696e695f6561736963617368697030317c6573745f696e695f6561736963617368706f72746130317c0d0a43504f203030315e3030315e3030315e3032202d204570736f6e5e3033202d205553425e315e3131353230305e4e5e305e305e315e315e315e315e544543444f5e42494f4d455e5e535e33305e3330305e325e393630305e4e5e385e305e4e5e4e5e4e5e4e5e305e305e305e305e5e305e305e5e5e5e325e305e315e445e315e325e325e325e325e325e325e325e325e325e325e325e325e325e325e315e325e375e365e4ee36f205574696c697a615e305e305e5e305e305e305e33305e32385e315e5e3032305e315e32322f31322f31325e31363a30303a30305e415e535e535e315e305e305e305e4ee36f205574696c697a615e305e305e5e305e305e325e305e305e305e305e305e544d2d5432305e305e31303532335e305e3130305e3130305e5e4e697467656e202d2048616d737465722044785e305e5e4e5e535e4ee36f205574696c697a615e305e535e4e5e5e545e4e5e4e5e545e435e4e5e305e4e5e305e4ee36f205574696c697a615e305e305e4e4643655e4e5e4570736f6e20544d2d5432305e315e315e305e5e4e5e4e5e305e2020202e2020202e2020202e5e305e5e31305e5e535e4e5e4e5e5e5e5e5e5e4e5e4e5e4e5e535e535e535e535e535e535e535e535e535e5e5e4e5e4e5e4e5e4e5e4e5e535e4e5e5e4e5e4e5e4e5e2020202e2020202e2020202e5e5e4e5e4e5e2020202e2020202e2020202e5e5e4e5e5e5e5e5e5e535e535e5e5e5e5e5e5e5e5e5e305e5e5e5e5e5e315e535e4e5e2020202e2020202e2020202e5e5e4e5e5e4e5e4e5e305e305e4e5e3030315e315e4ee36f205574696c697a615e305e305e5e305e305e2020202e2020202e2020202e5e305e305e5e5e305e305e5e305e305e305e4e414f55545e4e5e4e5e5e5e5e5e5e5e5e5e5e5e5e5e5e305e5e5e5e5e5e5e5e5e5e5e4e414f55545e5e5e305e4e5e5e5e5e5e5e305e305e5e305e5e305e305e305e305e305e305e305e305e5e5e495e5e5e5e305e5e5e5e5e5e5e5e5e305e5e5e305e5e5e305e305e5e305e305e305e305e5e5e5e5e5e5e5e0d0a43504f203030315e3030325e3030325e3032202d204570736f6e5e3033202d205553425e315e3131353230305e4e5e305e305e315e315e315e315e544543444f5e42494f4d455e5e535e33305e3330305e'

print(bytes.fromhex(df1))
print(bytes.fromhex(df2))
#print(bytes.fromhex(df3))

IP_SERVERUN = '192.168.1.6'
PORTA_SERVERUN = 9900

def Trata_Dados_Primarios(bytes):
    VALORES = []

    data = list(bytes)

    for i in data:
        if '|' in i:
            data[data.index(i)] = '\n'
    try:
        with open('bytes.txt', 'w', encoding='ISO-8859-1') as file:
            file.writelines(data)
            file.close()

        with open('bytes.txt', 'r', encoding='ISO-8859-1') as file_r:
            linhas = file_r.readlines()
            USER_FTP = linhas[0]
            USER_FTP = USER_FTP[13:24]
            PASS_FTP = linhas[1]
            PORTA_FTP = linhas[2]
            PORTA_INI = linhas[3]
            UNIDADE = linhas[4]

        if '\n' in USER_FTP:
            USER_FTP = list(USER_FTP)
            USER_FTP.remove('\n')

        if '\n' in PASS_FTP:
            PASS_FTP = list(PASS_FTP)
            PASS_FTP.remove('\n')
            PASS_FTP = ''.join(PASS_FTP)

        if '\n' in PORTA_FTP:
            PORTA_FTP = list(PORTA_FTP)
            PORTA_FTP.remove('\n')
            PORTA_FTP = ''.join(PORTA_FTP)

        if '\n' in PORTA_INI:
            PORTA_INI = list(PORTA_INI)
            PORTA_INI.remove('\n')
            PORTA_INI = ''.join(PORTA_INI)

        if '\n' in UNIDADE:
            UNIDADE = list(UNIDADE)
            UNIDADE.remove('\n')
            UNIDADE = ''.join(UNIDADE)

        VALORES.append(USER_FTP)
        VALORES.append(PASS_FTP)
        VALORES.append(PORTA_FTP)
        VALORES.append(PORTA_INI)
        VALORES.append(UNIDADE)

        return VALORES
    except:
        return None


def Tratamento_Dados_Secundarios(dados, arquivo):
    lista = list(dados)

    with open(arquivo, 'w', encoding='ISO-8859-1') as file:
        file.writelines(lista)

    with open(arquivo, 'r', encoding='ISO-8859-1') as file_id:
        linhas = file_id.readlines()

        for i in linhas:
            if 'PORT' in i:
                PORTA_FTP = list(i)
                for i2 in PORTA_FTP:
                    if ',' in i2:
                        PORTA_FTP[PORTA_FTP.index(i2)] = '\n'
                PORTA_FTP = ''.join(PORTA_FTP)
                file_id.close()

    with open(arquivo, 'w', encoding='ISO-8859-1') as novo:
        novo.writelines(PORTA_FTP)
        novo.close()

    with open(arquivo, 'r', encoding='ISO-8859-1') as file:
        linhas = file.readlines()
        id1 = linhas[4]
        id2 = linhas[5]

    return id1, id2


def CalculaPorta(id1, id2):
    id1 = list(id1)
    id2 = list(id2)

    for i in id1:
        if '\n' in i:
            id1.remove(id1[id1.index(i)])
            id1 = ''.join(id1)

    for o in id2:
        if '\n' in o:
            id2.remove(id2[id2.index(o)])
            id2 = ''.join(id2)

    P = (int(id1)*255) + int(id1) + int(id2)

    return P


def Tratamento_Dados_Ftp(bytes):
    for i in bytes:
        if i == ' ':
            bytes[bytes.index(i)] = '\n'
            ''.join(bytes)

    with open('dados_ftp.txt', 'w', encoding='ISO-8859-1') as file:
        file.writelines(bytes)
        file.close()

    with open('dados_ftp.txt', 'r', encoding='ISO-8859-1') as read:
        linhas = read.readlines()

        for i in linhas:
            if 'CONFIG' in i:
                arquivo_download = linhas[linhas.index(i)]
                read.close()
                tratar = list(arquivo_download)
                for i in tratar:
                    if i == '\n':
                        tratar.remove(tratar[arquivo_download.index(i)])
                return ''.join(tratar)
#Socket segunda conexão FTP
ftp2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#Criar 3 sockets de rede
#Socket que vai receber as informações primárias da aplicação
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((IP_SERVERUN, PORTA_SERVERUN))
s.sendall(b'\x02000000000600X002\x03\xfd\xc9\xea\r\n')
dados_primarios = s.recv(1024)

recv_pr = Trata_Dados_Primarios(list(dados_primarios.decode('ISO-8859-1')))
print(recv_pr)

#Socket que fará a conexão primária TCP/IP
Conx_pr = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
Conx_pr.connect((IP_SERVERUN, int(recv_pr[2])))
Conx_pr.sendall(str.encode('USER ' + recv_pr[0] + '\r\n'))
sleep(0.5)
Conx_pr.sendall(str.encode('PASS ' + recv_pr[1] + '\r\n'))
sleep(0.5)
Conx_pr.sendall(b'PASV\r\n')
sleep(0.5)
Conx_pr.sendall(b'CWD /\r\n')
sleep(0.5)
Conx_pr.sendall(b'CWD /002\r\n')
sleep(0.5)
Conx_pr.sendall(b'LIST /002\r\n')
sleep(0.5)
recebe_pr = Conx_pr.recv(1024)

dados = Tratamento_Dados_Secundarios(recebe_pr.decode('ISO-8859-1'), 'bytes.txt' )
porta_ftp = CalculaPorta(dados[0], dados[1])

#Socket que fará a comunicação com FTP
ftp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
ftp.connect((IP_SERVERUN, int(porta_ftp)))
dados_ftp = ftp.recv(8192)
ftp.close()
ft = Tratamento_Dados_Ftp(list(dados_ftp.decode('ISO-8859-1')))
Conx_pr.sendall(b'RETR 4448181576CONFIG.Exp\r\n')
sleep(2)
recebe_pr = Conx_pr.recv(1024)

ftp2.connect((IP_SERVERUN, int(porta_ftp)))

while True:
    dados_ftp = ftp2.recv(8192)

    print(recebe_pr)
    print(dados_ftp)
