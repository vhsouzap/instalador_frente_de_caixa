# -*- conding: ISO-8859-1 -*-

import os
import socket
from itertools import product
from time import sleep
import PySimpleGUI as sg
import zipfile
import crypt

# Pega o IP local da máquina
def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()

    return IP

# Função para validar os valores enviados pelo usuário e gravar
def Executation(values=''):
    os.chdir('/home/rpdv/frente')

    # Procedimento para alteração de arquivo tipo ini
    with open('sistema.ini', 'r', encoding='ISO-8859-1') as system:
        inf = system.readlines()

        for v in inf:
            if 'Unidade' in v:
                linha = list(inf[inf.index(v)].partition('='))
                linha[2] = values['unidade'] + '\n'
                linha = ''.join(linha)
                inf[inf.index(v)] = linha

        for i in inf:
            if 'Estacao' in i:
                linha = list(inf[inf.index(i)].partition('='))
                linha[2] = values['estacao'] + '\n'
                linha = ''.join(linha)
                inf[inf.index(i)] = linha

        for ip in inf:
            if 'EnderecoServerRPDV' in ip:
                linha = list(inf[inf.index(ip)].partition('='))
                linha[2] = values['IP_ServerUn'] + '\n'
                linha = ''.join(linha)
                inf[inf.index(ip)] = linha

        for port in inf:
            if 'PortaServerRPDV' in port:
                linha = list(inf[inf.index(port)].partition('='))
                linha[2] = values['cod_tcp'] +'\n'
                linha = ''.join(linha)
                inf[inf.index(port)] = linha

        system.close()

    with open('sistema.ini', 'w', encoding='ISO-8859-1') as system:
        system.writelines(inf)

    os.chdir('/home/rpdv/')
    with open('iniciarsudo.sh','r',encoding='ISO-8859-1') as inc:
        linhas = inc.readlines()
        linha = list(linhas[6].partition('1'))
        linha[1] = values['PassIncFile'] + '\n'
        linha = ''.join(linha)
        linhas[6] = linha
        inc.close()

    with open('iniciarsudo.sh','w',encoding='ISO-8859-1') as inc:
        inc.writelines(linhas)

    return janela_popup('ADVERTÊNCIA:','Configuração finalizada. Executar frente?')


def Instalation():
    #
    #
    #
    #

    #Verificar Diretório
    #
    #
    #
    #
    os.chdir('/home/rpdv')

    #try:
    #    os.chdir('/home/rpdv/')
    #except FileNotFoundError:
    #    return sg.popup('ERRO: ','Pasta RPDV não localizada. Sistema será fechado'), 1

    print('Descompactando arquivos para instalação.....')

    if os.path.exists('Frente_LUBUNTU') == False:
        z = zipfile.ZipFile('Inst_Frente_Lubuntu.zip', 'r')
        z.extractall()
        z.close()
        sleep(3)
        os.system('chmod 777 *')
        print('Arquivos descompactados....')
    else:
        print(f'Arquivos já descompactados em {os.getcwd()}.....')

    os.chdir('/home/rpdv/Frente_LUBUNTU')
    os.system('chmod +x instalar.sh')
    print('Executando instalar.sh no bash.....Aguarde')
    os.system('echo "S" | ./instalar.sh >> log_bash.txt')
    leitura('log_bash.txt', caminho=os.getcwd())
    sleep(2)
    print('Executando procedimento de links simbólicos....')
    os.chdir('/home/rpdv/frente')
    os.system('chmod 777 *')
    os.system('./atualiza.sh >> log_atualiza.txt')
    leitura('log_atualiza.txt', caminho=os.getcwd())

    return 0


def leitura(arquivo, caminho):

    os.chdir(caminho)

    with open(arquivo,'r',encoding='ISO-8859-1') as file:
        linhas = file.readlines()

        for i in linhas:
            sleep(0.03)
            print(i.strip())


def decrypt():
    word = ['CAIXA','123456','rpdv','wrpdv','2511','rickli 01 @']
    user = list(os.popen('users').read())
    if '\n' in user:
        user.remove('\n')
        user = ''.join(user)

    with open('/etc/shadow','r', encoding='ISO-8859-1') as passwd:
        linhas = passwd.readlines()

        for i in linhas:
            if user in i:
                salt = i[5:17]
                hash = i[17:103]

                for h in word:
                    if crypt.crypt(h,salt) == str(salt + hash):
                        return h
                    else:
                        return 1

# Função que verifica a existência do arquivo dentro do diretorio e se este arquivo possui uma unidade válida para retornar para o formulário, caso não exista retorna mensagem de informações ao input
def _fileOpenInfomationUN(objeto):
        encrypt = decrypt()

        if encrypt != 1:
            objeto['PassIncFile'].update(value=encrypt)
        else:
            objeto['PassIncFile'].update(value='123456')

        if os.path.exists('/home/rpdv/frente/sistema.ini'):

            os.chdir('/home/rpdv/frente')
            with open('sistema.ini', 'r', encoding='ISO-8859-1') as file:
                file_sys = file.readlines()
                linha = file_sys[2].partition('=')

                # Verifica se o arquivo possui unidade válida configurada e retorna para a função principal
                if linha[2] != '000\n' and linha[2] != '00\n' and linha[2] != '0\n' and linha != '':
                    linha = linha[2]
                    objeto['unidade'].update(value=linha.strip())

                # Verifica se o arquivo possui porta ServerUn - TCP configurada
                if file_sys[9] != '':
                    porta = file_sys[9].partition('=')
                    porta = porta[2]
                    objeto['cod_tcp'].update(value=porta.strip())
                else:
                    pass
        else:
            return objeto['unidade'].update(value='Arquivo sistema.ini não encontrado.'), sg.popup(
                'Arquivo sistema.ini não encontrado, por favor verifique a existência dele em /home/rpdv/frente.',
                title='ERRO:')


def _VerificationCheckActivate(values, objeto):
    if values.get('Nao_Configurar_Senha') == True:
        return objeto['PassIncFile'].update(disabled=True), 'D'
    else:
        return 'A'


def _ListsOutPutInputs():
    lista = []
    indices = []

    for elemento in range(0, 10):
        lista.append(str(elemento))
    resultado_permutacao = list(product(lista, repeat=3))

    for tuple in resultado_permutacao:
        indices.append(resultado_permutacao.index(tuple))

        for indice in indices:
            resultado_permutacao[indice] = ''.join(resultado_permutacao[indice])
            indices = []

    if '000' and '999' in resultado_permutacao:
        resultado_permutacao.remove('000')
        resultado_permutacao.remove('999')

        return resultado_permutacao


def _ExecutarEventos_window2_Inputs(value, objeto):
    valores = dict()
    verification = _ListsOutPutInputs()

    if value['estacao'] == '000' or value['estacao'] == '999':
        return objeto['estacao'].update(value=verification[0])
    else:
        if value['estacao'] != '0' and value['estacao'] != '00' and value['estacao'] != '000' and value['estacao'] != '999' and value['estacao'] != '':
            if value['estacao'] in verification:
                valores['estacao'] = value['estacao']

    if value['unidade'] == '000' or value['unidade'] == '999':
        return objeto['unidade'].update(value='001')
    else:
        if value['unidade'] != '0' and value['unidade'] != '00' and value['unidade'] != '000' and value['unidade'] != '999' and value['unidade'] != '':
            if value['unidade'] in verification:
                valores['unidade'] = value['unidade']

    if value['IP_ServerUn'] != '127.0.0.1' and value['IP_ServerUn'] != '':
        valores['IP_ServerUn'] = value['IP_ServerUn']

    if len(value['cod_tcp']) == 4:
        valores['cod_tcp'] = value['cod_tcp']

    if value['PassIncFile'] != '0' and value['PassIncFile'] != '00' and value['PassIncFile'] != '000' :
       valores['PassIncFile'] = value['PassIncFile']

    return valores


# Verifica evento disparado no momento do click em algum input do formulário
def _on_click_event_input(evento):
    if evento == 'estacao':
        var = 0
        return var

    elif evento == 'unidade':
        var = 1
        return var

    elif evento == 'IP_ServerUn':
        var = 2
        return var

    elif evento == 'PassIncFile':
        var = 3
        return var


# Valida os eventos disparados enquanto pressiona o botão continuar e enter - muda o foco do objeto conforme pressionamentos
def _ValidationKeyboardEvents(objeto, controlSetFocus):
    if controlSetFocus == 'SetEstac':
        objeto['estacao'].SetFocus(force=True)

    elif controlSetFocus == 1:
        _ExecutarEventos_window2_Inputs(value, janela2_exec)
        objeto['unidade'].SetFocus(force=True)

    elif controlSetFocus == 2:
        _ExecutarEventos_window2_Inputs(value, janela2_exec)
        objeto['IP_ServerUn'].SetFocus(force=True)

    elif controlSetFocus == 3:
        objeto['cod_tcp'].SetFocus(force=True)
        _ExecutarEventos_window2_Inputs(value, janela2_exec)

    elif controlSetFocus == 4:
        objeto['PassIncFile'].SetFocus(force=True)
        _ExecutarEventos_window2_Inputs(value, janela2_exec)

    elif controlSetFocus == 0:
        _ExecutarEventos_window2_Inputs(value, janela2_exec)
        objeto['estacao'].SetFocus(force=True)


# Define o layout da janela principal
def janela1():
    sg.theme('DarkBrown4')

    layout = [
        [sg.Text(
            '---------------------------------------------------------------------------------------------------')],
        [sg.Text('OLÁ, SEJA BEM VINDO AO INSTALADOR DO FRENTE DE CAIXA!', background_color='white',
                 text_color='black')],
        [sg.Text(
            '---------------------------------------------------------------------------------------------------')],
        [sg.Text('Instalar o Frente?')],
        [sg.Checkbox('Sim..', default=True, enable_events=True, key='Instalar'),
         sg.Checkbox('Não..', enable_events=True, key='NaoInstalar')],
        [sg.Text('Configurar o sistema.ini e demais parâmetros após instalação?')],
        [sg.Checkbox('Sim..', default=False, enable_events=True, key='Configurar'),
         sg.Checkbox('Não..', default=True, enable_events=True, key='NaoConfigurar')],
        [sg.Text('Iniciar o frente após instalação?')],
        [sg.Checkbox('Sim..', default=True, enable_events=True, key='Iniciar_Frente'),
         sg.Checkbox('Não..', default=False, enable_events=True, key='Nao_Iniciar_Frente')],
        [sg.Text('Configurar inicialização Frente?')],
        [sg.Checkbox('Sim..', default=False,
                     enable_events=True, key='Configurar_Senha'),
         sg.Checkbox('Não..', default=True, enable_events=True, key='Nao_Configurar_Senha')],
        [sg.Text('Descriptografia de senha root: ')],
        [sg.Checkbox('Sim..', default=True, enable_events=True, key='Crypt'),
         sg.Checkbox('Não..', enable_events=True, default=False, key='NoCrypt')],
        [sg.Button('Continuar', key='Next', enable_events=True,
                   tooltip='Envia informações e retorna uma nova janela de inserção de dados.'),
         sg.Button('Sair', key='Close', enable_events=True, tooltip='Não faz nada ; D')],
        [sg.Text('                                                                             Version: 1.0.1')]
    ]

    return sg.Window('Inicialização', return_keyboard_events=True, size=(430, 430), icon='python.ico', layout=layout,
                     finalize=True)

# Define o layout da janela secundária
def janela2():
    sg.theme('DarkBrown4')

    layout2 = [
        [sg.Text('Digite o número da estação a ser configurada (sistema.ini): ',
                 tooltip='Se a estação já estiver configurada em sistema.ini input recebe valor'),
         sg.Input(enable_events=True, key='estacao')],
        [sg.Text('Digite o código da unidade desejada: '), sg.Input(enable_events=True, key='unidade')],
        [sg.Text('Digite o IP do Servidor do PDV: ', tooltip='Passa para o arquivo sistema.ini o IP digitado'),
         sg.Input(enable_events=True, key='IP_ServerUn')],
        [sg.Text('Digite porta TCP - ServerUn: '), sg.Input(enable_events=True, key='cod_tcp')],
        [sg.Text('Digite o pass root para iniciarsudo.sh: '),
         sg.Input(enable_events=True, key='PassIncFile', disabled=False)],
        [sg.Button('Continuar', key='continue', enable_events=True),
         sg.Button('Voltar', key='back', auto_size_button=True)]
    ]

    return sg.Window('Parâmetros de configuração: ', return_keyboard_events=True, size=(800, 160), icon='python.ico',
                     layout=layout2, finalize=True)

def janela3():
    sg.theme('DarkBrown4')

    layout3 = [
        [sg.Text('Monitoramento de processo de execução', tooltip='Mostra os processos executados durante instalação.')],
        [sg.Output(size=(780,190))]
    ]

    return sg.Window('Monitoramento', return_keyboard_events=True, layout=layout3, finalize=True, size=(900,500))


def janela_popup(titulo_janela, mensagem, size=(300,100)):
    sg.theme('DarkBrown4')

    layout4 = [
        [sg.Text(mensagem)],
        [sg.Button('Sim', key='Sim_msg'), sg.Button('Não', key='Nao_msg')]
    ]
    return sg.Window(titulo_janela, return_keyboard_events=True, layout=layout4, finalize=True, size=size)

janela1_exec = janela1()

controlSetFocus = 0

while True:

    window, event, value = sg.read_all_windows()

    try:
        if event == 'NaoInstalar':
            janela1_exec['Instalar'].update(value=False)
            janela1_exec['NaoInstalar'].update(value=True)

        elif event == 'Instalar':
            janela1_exec['NaoInstalar'].update(value=False)
            janela1_exec['Instalar'].update(value=True)

        elif event == 'Configurar':
            janela1_exec['NaoConfigurar'].update(value=False)
            janela1_exec['Configurar'].update(value=True)

        elif event == 'NaoConfigurar':
            janela1_exec['NaoConfigurar'].update(value=True)
            janela1_exec['Configurar'].update(value=False)

        elif event == 'Configurar_Senha':
            janela1_exec['Nao_Configurar_Senha'].update(value=False)
            janela1_exec['Configurar_Senha'].update(value=True)

        elif event == 'Nao_Configurar_Senha':
            janela1_exec['Nao_Configurar_Senha'].update(value=True)
            janela1_exec['Configurar_Senha'].update(value=False)

        elif event == 'Iniciar_Frente':
            janela1_exec['Nao_Iniciar_Frente'].update(value=False)
            janela1_exec['Iniciar_Frente'].update(value=True)

        elif event == 'Nao_Iniciar_Frente':
            janela1_exec['Iniciar_Frente'].update(value=False)
            janela1_exec['Nao_Iniciar_Frente'].update(value=True)

        elif event == 'Crypt':
            janela1_exec['NoCrypt'].update(value=False)
            janela1_exec['Crypt'].update(value=True)

        elif event == 'NoCrypt':
            janela1_exec['Crypt'].update(value=False)
            janela1_exec['NoCrypt'].update(value=True)

        elif window == janela1_exec and event == 'Escape:27':
            break

        elif window == janela1_exec and (event == 'Right:114'):
            sg.Button.set_focus(janela1_exec['Close'])

        elif window == janela1_exec and (event == 'Left:113'):
            sg.Button.set_focus(janela1_exec['Next'])

        elif window == janela1_exec and (event == 'Next' or event == '\r'):

            if os.path.exists('/home/rpdv/frente') == True:
                if value.get('Configurar') == True:
                    valor_check = 0
                else:
                    valor_check = 1

                janela_atencao_Next = janela_popup('ATENÇÃO:','Pasta Frente já existe em /home/rpdv/. Reinstalar?', size=(400,100))
            else:
                janela1_exec.hide()
                janela3_exec = janela3()
                janela3_exec.un_hide()
                validar = Instalation()

                if validar == 0:
                    janela3_exec.close()

                sleep(2)

                if value.get('Configurar') == True:
                    if os.path.exists('/home/rpdv/frente'):
                        janela2_exec = janela2()
                        janela2_exec['estacao'].SetFocus(force=True)
                        _fileOpenInfomationUN(janela2_exec)
                        variavel = _VerificationCheckActivate(value, janela2_exec)
                    else:
                        janela1_exec.un_hide()
                else:
                    janela1_exec.un_hide()

        elif window == janela1_exec and (event == 'Close' or event == sg.WIN_CLOSED):
            break

        elif window == janela_atencao_Next and (event == 'Nao_msg'):
            janela_atencao_Next.close()

            if valor_check == 0:
                janela1_exec.hide()
                janela2_exec = janela2()
                janela2_exec['estacao'].SetFocus(force=True)
                _fileOpenInfomationUN(janela2_exec)
                variavel = _VerificationCheckActivate(value, janela2_exec)
            else:
                janela1_exec.un_hide()

        #Procedimento após validação existência pasta frente ao pressionar continuar em janela1 validando os eventos executados
        elif window == janela_atencao_Next and event == 'Sim_msg':
            os.system('rm -rf /home/rpdv/frente')
            janela1_exec.hide()
            janela3_exec = janela3()
            janela3_exec.un_hide()
            validar = Instalation()
            janela3_exec.close()

        elif event == 'Right:114' and window == janela_atencao_Next:
           sg.Button.set_focus(janela_atencao_Next['Nao_msg'])

        elif event == 'Left:113' and window == janela_atencao_Next:
            sg.Button.set_focus(janela_atencao_Next['Sim_msg'])

        elif window == janela2_exec and event == 'back':
            if os.path.exists('/home/rpdv/frente') == True:
                janela_atencao = janela_popup('ATENÇÃO:','Verificado que o frente já foi instalado.. Se SIM for selecionado será efetuado exclusão da pasta Frente.')

                if event == 'Right:114' and window == janela_atencao:
                    sg.Button.set_focus(janela_atencao['Nao_msg'])
                elif event == 'Left:113' and window == janela_atencao:
                    sg.Button.set_focus(janela_atencao['Sim_msg'])

            janela2_exec.hide()
            janela3_exec.hide()
            janela1_exec.un_hide()

        elif window == janela2_exec and event == 'Escape:27':
            janela2_exec.hide()
            janela1_exec.un_hide()

        elif window == janela2_exec and event == sg.WIN_CLOSED:
            janela2_exec.close()
            janela1_exec.un_hide()

        elif window == janela2_exec and event == '\r':

            if controlSetFocus == 0:
                controlSetFocus = 1  # Setar na função foco no campo unidade
                _ValidationKeyboardEvents(janela2_exec, controlSetFocus=controlSetFocus)

            elif controlSetFocus == 1:
                controlSetFocus = 2  # Setar na função foco campo IP_ServerUn ao pressionar novamente enter
                _ValidationKeyboardEvents(janela2_exec, controlSetFocus=controlSetFocus)

            elif controlSetFocus == 2:
                controlSetFocus = 3 #Seta foco no campo cod_tcp ao pressionar novamente enter
                _ValidationKeyboardEvents(janela2_exec, controlSetFocus=controlSetFocus)

            elif controlSetFocus == 3:
                try:
                    if variavel[1] == 'D':
                        controlSetFocus = 'SetEstac'  # Se o CheckBox do campo PassIncFile estiver ativo como nao, seta foco no campo estacao
                        _ValidationKeyboardEvents(janela2_exec, controlSetFocus)
                        controlSetFocus = 0
                except IndexError:
                    controlSetFocus = 4  # Se o campo PassIncFile estiver ativo seta foco no campo PassIncFile
                    _ValidationKeyboardEvents(janela2_exec, controlSetFocus=controlSetFocus)

            elif controlSetFocus == 3:
                controlSetFocus = 'SetEstac'
                _ValidationKeyboardEvents(janela2_exec, controlSetFocus=controlSetFocus)
                controlSetFocus = 0

            elif controlSetFocus == 'SetEstac':
                controlSetFocus = 0
                janela2_exec['estacao'].SetFocus(force=True)

        evento = _on_click_event_input(event)

        # Procedimento para verificar em qual input o usuário clicou
        if evento == 0 or evento == 1 or evento == 2 or evento == 3:
            if evento == 0:
                controlSetFocus = 0

            elif evento == 1:
                controlSetFocus = 1

            elif evento == 2:
                controlSetFocus = 2

            # Se usuário clicou no input habilitado de root linux
            elif evento == 3:
                controlSetFocus = 'SetEstac'

        elif window == janela2_exec and event == 'continue':
            # Função para validar os valores recebidos pelo usuário
            infrm = _ExecutarEventos_window2_Inputs(value, janela2_exec)
            val = Executation(infrm)

        elif window == val and event == 'Right:114':
            sg.Button.set_focus(val['Nao_msg'])

        elif window == val and event == 'Left:113':
            sg.Button.set_focus(val['Sim_msg'])

        elif window == val and event == 'Sim_msg':
            os.chdir('/home/rpdv/')
            os.system('./iniciarsudo.sh')

        elif window == val and event == 'Nao_msg':
            break

    except NameError:
        pass