# -*- coding: ISO-8859-1 -*-

import os
import PySimpleGUI as sg
import crypt

'''def decrypt():
    word = ['CAIXA','123456','rpdv','wrpdv','2511']
    user = list(os.popen('users').read())
    if '\n' in user:
        user.remove('\n')
        user = ''.join(user)

    with open('/etc/shadow','r', encoding='ISO-8859-1') as passwd:
        linhas = passwd.readlines()

        for i in linhas:
            if user in i:
                salt = i[5:17]
                hash = i[17:103]

                for h in word:
                    if crypt.crypt(h,salt) == str(salt + hash):
                        return user
if decrypt() == 'rpdv':
    print('O usuario � rpdv')'''
os.chdir('/home/rpdv/')
os.system('./iniciarsudo.sh')